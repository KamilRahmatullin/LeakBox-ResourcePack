int enumcosmetic_camera_marker(sampler2D atlas, vec2 uv) {
    ivec2 size = textureSize(atlas, 0);
    ivec2 position = clamp(ivec2(uv * vec2(size)), ivec2(0), size - 1);
    ivec4 pixel = ivec4(round(texelFetch(atlas, position, 0) * 255.0));
    return (pixel.r & 3) == 3 && (pixel.g & 3) == 3 ? pixel.a : 0;
}

vec4 enumcosmetic_camera_color(sampler2D atlas, vec2 uv, vec3 position, vec3 tint) {
    vec4 color = texture(atlas, uv);
    if (color.a > 0.0 && color.a < 0.99) {
        int marker = enumcosmetic_camera_marker(atlas, uv);
        vec3 bytes = round(tint * 255.0);
        if (marker == 249) {
            // Cover the hem even while the camera eases into a new pose.
            float scale = all(equal(bytes, vec3(255.0))) ? 1.0
                : ((bytes.r - 128.0) * 128.0 + bytes.g - 128.0) / 64.0;
            if (length(position) < 2.25 * scale) discard;
            color.rgb /= tint;
            if (color.a > 0.94) color.a = 1.0;
        } else if (marker == 247 && color.a > 0.94) {
            // The hat tint encodes its displacement from the wearer's eyes, including in flight.
            if (all(equal(bytes, vec3(255.0)))) {
                if (length(position) < 1.35) discard;
            } else {
                vec3 offset = (bytes - vec3(128.0)) / 16.0;
                if (length(position - offset) < 1.75) discard;
                // The vanilla lighting will multiply by this tint later.
                color.rgb /= tint;
            }
            color.a = 1.0;
        }
    }
    return color;
}
