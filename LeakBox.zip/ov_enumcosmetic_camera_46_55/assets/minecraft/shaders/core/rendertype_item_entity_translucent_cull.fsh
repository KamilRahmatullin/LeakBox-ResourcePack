#version 150

#moj_import <enumcosmetic:hat_camera.glsl>
#moj_import <minecraft:fog.glsl>

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;

out vec4 fragColor;

in vec3 enumcosmeticPosition;
flat in vec3 enumcosmeticTint;

void main() {
    vec4 color = enumcosmetic_camera_color(Sampler0, texCoord0, enumcosmeticPosition, enumcosmeticTint) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
